# ****************************************************************************
# Licensed Materials - Property of IBM
# "Restricted Materials of IBM"
# Copyright (C) IBM Corp. 2016 All Rights Reserved.
#
# Copying, redistribution and/or modification is prohibited.
# U.S. Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
# ****************************************************************************

java -jar AccessibilityCmd.jar "$@"
